class Task():
    def __init__(self,task,explanations,priority):
        self.task=task
        self.explanations=explanations
        self.priority=priority